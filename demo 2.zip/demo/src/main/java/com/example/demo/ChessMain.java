package com.example.demo;

import com.example.demo.main.GamePanel;
import javafx.stage.Stage;

import javax.swing.JFrame;

public class ChessMain {

    public static void main(String[] args) {
        ChessMain chessGame = new ChessMain();
        chessGame.start(); // Start the game using the start method
    }

    public void start() {
        // Create the JFrame for the chess game
        JFrame window = new JFrame("Chess");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);

        // Add the GamePanel to the JFrame
        GamePanel gp = new GamePanel();
        window.add(gp);
        window.pack();

        // Center the window on the screen
        window.setLocationRelativeTo(null);

        // Make the window visible
        window.setVisible(true);

        // Launch the game
        gp.launchGame();
    }


}
