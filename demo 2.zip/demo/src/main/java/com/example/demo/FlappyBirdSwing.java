package com.example.demo;

import javax.swing.*;
import java.awt.*;

public class FlappyBirdSwing extends JFrame {

    public FlappyBirdSwing() {
        // Set up Swing JFrame
        int boardWidth = 360;
        int boardHeight = 640;

        setSize(boardWidth, boardHeight);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(173, 216, 230)); // LIGHTBLUE
        add(panel);
    }

    public static void main(String[] args) {
        // Launch the Swing application
        SwingUtilities.invokeLater(() -> {
            FlappyBirdSwing flappyBirdSwing = new FlappyBirdSwing();
            flappyBirdSwing.setVisible(true);
        });
    }
}