package com.example.demo;

import java.util.HashMap;

import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HangmanMain extends Application {

    // Constants for application size and font
    private static final int APP_W = 900; // Application width
    private static final int APP_H = 500; // Application height
    private static final Font DEFAULT_FONT = new Font("Courier", 36); // Default font for text

    private static final int POINTS_PER_LETTER = 100; // Points awarded per correct letter
    private static final float BONUS_MODIFIER = 0.2f; // Bonus multiplier for consecutive correct guesses

    // Properties for game state
    private SimpleStringProperty word = new SimpleStringProperty(); // Current word to guess
    private SimpleIntegerProperty lettersToGuess = new SimpleIntegerProperty(); // Number of remaining letters
    private SimpleIntegerProperty score = new SimpleIntegerProperty(); // Current score
    private float scoreModifier = 1.0f; // Multiplier for score calculation
    private SimpleBooleanProperty playable = new SimpleBooleanProperty(); // Tracks if the game is playable

    private ObservableList<Node> letters; // List of letter nodes in the word
    private HashMap<Character, Text> alphabet = new HashMap<>(); // Map of alphabet characters to text nodes
    private HangmanImage hangman = new HangmanImage(); // Hangman figure
    private WordReader wordReader = new WordReader(); // Word generator

    /**
     * Creates the main content of the game, including the layout, buttons, and visual components.
     */
    public Parent createContent() {
        // Creates the row for displaying guessed letters
        HBox rowLetters = new HBox();
        rowLetters.setAlignment(Pos.CENTER);
        letters = rowLetters.getChildren();

        // Binds the game's playable state to lives and letters left
        playable.bind(hangman.lives.greaterThan(0).and(lettersToGuess.greaterThan(0)));
        playable.addListener((obs, old, newValue) -> {
            if (!newValue.booleanValue())
                stopGame();
        });

        // Creates a button to start a new game
        Button btnAgain = new Button("NEW GAME");
        btnAgain.disableProperty().bind(playable);
        btnAgain.setOnAction(event -> startGame());

        // Creates the alphabet row
        HBox rowAlphabet = new HBox(5);
        rowAlphabet.setAlignment(Pos.CENTER);
        for (char c = 'A'; c <= 'Z'; c++) {
            Text t = new Text(String.valueOf(c));
            t.setFont(DEFAULT_FONT);
            alphabet.put(c, t);
            rowAlphabet.getChildren().add(t);
        }
        Text hyphen = new Text("-");
        hyphen.setFont(DEFAULT_FONT);
        alphabet.put('-', hyphen);
        rowAlphabet.getChildren().add(hyphen);

        // Displays the score
        Text textScore = new Text();
        textScore.textProperty().bind(score.asString().concat(" Points"));

        // Hangman and score display row
        HBox rowHangman = new HBox(10, btnAgain, textScore, hangman);
        rowHangman.setAlignment(Pos.CENTER);

        // Vertical layout for all components
        VBox vBox = new VBox(10);
        vBox.getChildren().addAll(rowLetters, rowAlphabet, rowHangman);
        return vBox;
    }

    /**
     * Ends the game by revealing all letters in the word.
     */
    private void stopGame() {
        for (Node n : letters) {
            Letter letter = (Letter) n;
            letter.show();
        }
    }

    /**
     * Starts a new game, resetting all state and selecting a new word.
     */
    private void startGame() {
        for (Text t : alphabet.values()) {
            t.setStrikethrough(false);
            t.setFill(Color.BLACK);
        }

        hangman.reset(); // Resets hangman figure
        word.set(wordReader.getRandomWord().toUpperCase()); // Selects a new word

        // Counts letters to guess
        int letterCount = 0;
        for (char c : word.get().toCharArray()) {
            if (c != ' ' && c != '-') {
                letterCount++;
            }
        }
        lettersToGuess.set(letterCount);

        letters.clear(); // Clears the display of previous word
        for (char c : word.get().toCharArray()) {
            letters.add(new Letter(c)); // Adds new letters to the display
        }
    }

    /**
     * Represents the Hangman figure with individual body parts.
     */
    private static class HangmanImage extends Parent {
        private SimpleIntegerProperty lives = new SimpleIntegerProperty(); // Tracks remaining lives

        public HangmanImage() {
            // Creates the Hangman figure (head, spine, arms, legs)
            Circle head = new Circle(20);
            head.setTranslateX(100);

            Line spine = new Line(100, 20, 100, 70);
            Line leftArm = new Line(100, 20, 140, 30);
            Line rightArm = new Line(100, 20, 60, 30);
            Line leftLeg = new Line(100, 70, 125, 120);
            Line rightLeg = new Line(100, 70, 75, 120);

            getChildren().addAll(head, spine, leftArm, rightArm, leftLeg, rightLeg);
            lives.set(getChildren().size());
        }

        /**
         * Resets the hangman figure by hiding all parts.
         */
        public void reset() {
            getChildren().forEach(node -> node.setVisible(false));
            lives.set(getChildren().size());
        }

        /**
         * Reveals one body part when a life is lost.
         */
        public void takeAwayLife() {
            for (Node n : getChildren()) {
                if (!n.isVisible()) {
                    n.setVisible(true);
                    lives.set(lives.get() - 1);
                    break;
                }
            }
        }
    }

    /**
     * Represents a single letter in the word with a background and hidden text.
     */
    private static class Letter extends StackPane {
        private Rectangle bg = new Rectangle(40, 60);
        private Text text;

        public Letter(char letter) {
            bg.setFill(letter == ' ' || letter == '-' ? Color.TRANSPARENT : Color.WHITE);
            bg.setStroke(Color.BLUE);

            text = new Text(String.valueOf(letter).toUpperCase());
            text.setFont(DEFAULT_FONT);
            text.setVisible(false);

            setAlignment(Pos.CENTER);
            getChildren().addAll(bg, text);
        }

        /**
         * Reveals the letter with a flipping animation.
         */
        public void show() {
            RotateTransition rt = new RotateTransition(Duration.seconds(1), bg);
            rt.setAxis(Rotate.Y_AXIS);
            rt.setToAngle(180);
            rt.setOnFinished(event -> text.setVisible(true));
            rt.play();
        }

        /**
         * Checks if this letter matches a given character.
         */
        public boolean isEqualTo(char other) {
            return text.getText().equals(String.valueOf(other).toUpperCase());
        }
    }

    /**
     * Sets up the primary stage and handles key events for guessing letters.
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = new Scene(createContent());
        scene.setOnKeyPressed((KeyEvent event) -> {
            if (event.getText().isEmpty()) return;

            char pressed = event.getText().toUpperCase().charAt(0);
            if ((pressed < 'A' || pressed > 'Z') && pressed != '-') return;

            if (playable.get()) {
                Text t = alphabet.get(pressed);
                if (t.isStrikethrough()) return;

                t.setFill(Color.BLUE);
                t.setStrikethrough(true);

                boolean found = false;

                for (Node n : letters) {
                    Letter letter = (Letter) n;
                    if (letter.isEqualTo(pressed)) {
                        found = true;
                        score.set(score.get() + (int) (scoreModifier * POINTS_PER_LETTER));
                        lettersToGuess.set(lettersToGuess.get() - 1);
                        letter.show();
                    }
                }

                if (!found) {
                    hangman.takeAwayLife();
                    scoreModifier = 1.0f;
                } else {
                    scoreModifier += BONUS_MODIFIER;
                }
            }
        });

        primaryStage.setResizable(false);
        primaryStage.setWidth(APP_W);
        primaryStage.setHeight(APP_H);
        primaryStage.setTitle("Hangman");
        primaryStage.setScene(scene);
        primaryStage.show();
        startGame();
    }

    /**
     * Main method to launch the application.
     */
    public static void main(String[] args) {
        launch(args);
    }
}