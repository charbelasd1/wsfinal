package com.example.demo;

import java.util.Random;

public class MazeGenerator {
    private final int rows, cols;
    private final int[][] maze;

    public MazeGenerator(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.maze = new int[rows][cols];
        generateMaze(0, 0);
    }

    private void generateMaze(int row, int col) {
        maze[row][col] = 1;
        int[] directions = {0, 1, 2, 3};
        shuffleArray(directions);

        for (int direction : directions) {
            int newRow = row, newCol = col;
            if (direction == 0 && row > 1) newRow -= 2;
            if (direction == 1 && row < rows - 2) newRow += 2;
            if (direction == 2 && col > 1) newCol -= 2;
            if (direction == 3 && col < cols - 2) newCol += 2;

            if (maze[newRow][newCol] == 0) {
                maze[(row + newRow) / 2][(col + newCol) / 2] = 1;
                generateMaze(newRow, newCol);
            }
        }
    }

    private void shuffleArray(int[] array) {
        Random rand = new Random();
        for (int i = array.length - 1; i > 0; i--) {
            int index = rand.nextInt(i + 1);
            int temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }

    public int[][] getMaze() {
        return maze;
    }
}
