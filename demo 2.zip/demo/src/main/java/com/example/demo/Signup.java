package com.example.demo;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Signup extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Left pane setup (similar to Login)
        AnchorPane leftPane = new AnchorPane();
        leftPane.setPrefSize(350, 500);
        leftPane.setStyle("-fx-background-color: #8F00FF;");

        try {
            Image logoImage = new Image("cloudlogo.png");
            ImageView logoImageView = new ImageView(logoImage);
            logoImageView.setFitWidth(150);
            logoImageView.setFitHeight(150);
            logoImageView.setLayoutX(90);
            logoImageView.setLayoutY(90);

            leftPane.getChildren().add(logoImageView);
        } catch (Exception e) {
            System.out.println("Error loading image: " + e.getMessage());
        }


        Text cloudGamesText = new Text("CLOUD GAMES");
        cloudGamesText.setFont(new Font(25));
        cloudGamesText.setLayoutX(84);
        cloudGamesText.setLayoutY(277);

        // Create a Pac-Man-like arc
        Arc arc = new Arc(99, 396, 84, 77, 45, 270); // Start angle 45, extent angle 270
        arc.setFill(Color.YELLOW);
        arc.setStroke(Color.BLACK);

        // Create a black triangle for Pac-Man's mouth
        Polygon mouth = new Polygon();
        mouth.getPoints().addAll(new Double[] {
                99.0, 396.0, // Point at the center of the arc
                160.0, 340.0, // Point to the right
                160.0, 450.0 // Point to the left
        });
        mouth.setFill(Color.web("#8f00ff"));

        Circle circle1 = new Circle(158, 396, 10, Color.DODGERBLUE);
        circle1.setStroke(Color.BLACK);

        Circle circle2 = new Circle(193, 396, 10, Color.RED);
        circle2.setStroke(Color.BLACK);

        Circle circle3 = new Circle(226, 396, 10, Color.LIMEGREEN);
        circle3.setStroke(Color.BLACK);

        Circle circle4 = new Circle(260, 396, 10, Color.MAGENTA);
        circle4.setStroke(Color.BLACK);

        Circle smallCircle = new Circle(100, 360, 10);
        smallCircle.setStroke(Color.BLACK);

        leftPane.getChildren().addAll(cloudGamesText, arc, mouth, circle1, circle2, circle3, circle4, smallCircle);

        // Right pane setup
        AnchorPane rightPane = new AnchorPane();
        rightPane.setPrefSize(415, 500);
        rightPane.setStyle("-fx-background-color: transparent;");

        // Title
        TextField signupTitle = new TextField("User Signup");
        signupTitle.setEditable(false);
        signupTitle.setLayoutX(137);
        signupTitle.setLayoutY(50);
        signupTitle.setPrefSize(100, 50);
        signupTitle.setStyle("-fx-background-color: transparent; -fx-alignment: middle; -fx-font-weight: bold;");

        // Input Fields
        TextField nameField = new TextField();
        nameField.setPromptText("First Name");
        nameField.setLayoutX(117);
        nameField.setLayoutY(100);
        nameField.setStyle("-fx-background-color: transparent; -fx-border-color: #8F00FF; -fx-border-width: 0px 0px 2px 0px;");
        nameField.setCursor(Cursor.TEXT);

        TextField familyNameField = new TextField();
        familyNameField.setPromptText("Last Name");
        familyNameField.setLayoutX(117);
        familyNameField.setLayoutY(140);
        familyNameField.setStyle("-fx-background-color: transparent; -fx-border-color: #8F00FF; -fx-border-width: 0px 0px 2px 0px;");
        familyNameField.setCursor(Cursor.TEXT);

        TextField ageField = new TextField();
        ageField.setPromptText("Age");
        ageField.setLayoutX(117);
        ageField.setLayoutY(180);
        ageField.setStyle("-fx-background-color: transparent; -fx-border-color: #8F00FF; -fx-border-width: 0px 0px 2px 0px;");
        ageField.setCursor(Cursor.TEXT);

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setLayoutX(117);
        usernameField.setLayoutY(220);
        usernameField.setStyle("-fx-background-color: transparent; -fx-border-color: #8F00FF; -fx-border-width: 0px 0px 2px 0px;");
        usernameField.setCursor(Cursor.TEXT);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setLayoutX(117);
        passwordField.setLayoutY(260);
        passwordField.setStyle("-fx-background-color: transparent; -fx-border-color: #8F00FF; -fx-border-width: 0px 0px 2px 0px;");
        passwordField.setCursor(Cursor.TEXT);

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");
        confirmPasswordField.setLayoutX(117);
        confirmPasswordField.setLayoutY(300);
        confirmPasswordField.setStyle("-fx-background-color: transparent; -fx-border-color: #8F00FF; -fx-border-width: 0px 0px 2px 0px;");
        confirmPasswordField.setCursor(Cursor.TEXT);

        Label messageLabel = new Label();
        messageLabel.setLayoutX(117);
        messageLabel.setLayoutY(340);
        messageLabel.setTextFill(Color.RED);


        Button backToLoginButton = new Button("Back");
        backToLoginButton.setLayoutX(200);
        backToLoginButton.setLayoutY(370);
        backToLoginButton.setPrefSize(86, 30);
        backToLoginButton.setStyle("-fx-background-color: #8F00FF; -fx-text-fill: white;");
        backToLoginButton.setCursor(Cursor.HAND);


        backToLoginButton.setOnAction(event -> {
            try {
                new Login().start(primaryStage);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });


        rightPane.getChildren().add(backToLoginButton);


        Button signUpButton = new Button("Sign Up");
        signUpButton.setLayoutX(100);
        signUpButton.setLayoutY(370);
        signUpButton.setPrefSize(86, 30);
        signUpButton.setStyle("-fx-background-color: #8F00FF; -fx-text-fill: white;");
        signUpButton.setCursor(Cursor.HAND);

        // Button Action
        signUpButton.setOnAction(event -> {
            String name = nameField.getText();
            String familyName = familyNameField.getText();
            String ageText = ageField.getText();
            String username = usernameField.getText();
            String password = passwordField.getText();
            String confirmPassword = confirmPasswordField.getText();

            if (!password.equals(confirmPassword)) {
                messageLabel.setText("Passwords do not match!");
            } else if (name.isEmpty() || familyName.isEmpty() || ageText.isEmpty() || username.isEmpty() || password.isEmpty()) {
                messageLabel.setText("All fields are required!");
            } else {
                try {
                    int age = Integer.parseInt(ageText);
                    if (signUpUser(name, familyName, age, username, password)) {
                        messageLabel.setTextFill(Color.GREEN);
                        messageLabel.setText("Signup successful! Redirecting to login...");
                        new Login().start(primaryStage); // Redirect to Login page
                    } else {
                        messageLabel.setText("Signup failed. Username may already exist.");
                    }
                } catch (NumberFormatException e) {
                    messageLabel.setText("Age must be a valid number!");
                }
            }
        });

        rightPane.getChildren().addAll(signupTitle, nameField, familyNameField, ageField, usernameField, passwordField,
                confirmPasswordField, signUpButton, messageLabel);

        // Set up the BorderPane layout
        BorderPane root = new BorderPane();
        root.setLeft(leftPane);
        root.setCenter(rightPane);

        // Create the scene
        Scene scene = new Scene(root, 700, 500);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Signup");
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    private boolean signUpUser(String name, String familyName, int age, String username, String password) {
        String query = "INSERT INTO users (name, family_name, age, username, password) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, familyName);
            stmt.setInt(3, age);
            stmt.setString(4, username);
            stmt.setString(5, password);

            stmt.executeUpdate();
            return true;
        } catch (Exception e) {
            if (e.getMessage().contains("Duplicate entry")) {
                System.out.println("Username already exists.");
            } else {
                e.printStackTrace();
            }
            return false;
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
