package com.example.demo;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import javax.swing.*;

public class App extends Application {

    public static void main(String[] args) {
        // Launch the JavaFX application
        launch(args);
    }

    @Override
    public void start(Stage flappyStage) {
        // Set up JavaFX stage
            flappyStage.setTitle("Flappy Bird - JavaFX");
            int boardWidth = 320;
            int boardHeight = 560;

            // Create a simple placeholder for the game
            StackPane root = new StackPane();
            Rectangle placeholder = new Rectangle(boardWidth, boardHeight, Color.LIGHTBLUE);
            root.getChildren().add(placeholder);

            Scene scene = new Scene(root, boardWidth, boardHeight);
            flappyStage.setScene(scene);
            flappyStage.setResizable(false);
            flappyStage.show();

            // Call Swing implementation (optional)
            launchSwing();
        }

    public void launchSwing() {
        // Set up Swing JFrame
        int boardWidth = 380;
        int boardHeight = 660;

        JFrame frame = new JFrame("Flappy Bird - Swing");
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        FlappyBird flappyBird = new FlappyBird();
        frame.add(flappyBird);
        frame.pack();
        flappyBird.requestFocus();
        frame.setVisible(true);

    }
}
