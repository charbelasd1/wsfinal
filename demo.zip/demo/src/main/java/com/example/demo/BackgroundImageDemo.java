package com.example.demo;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class BackgroundImageDemo extends Application {

    @Override
    public void start(Stage stage) {
        // Create a Pane for the background
        Pane root = new Pane();

        // Load the background image
        String imagePath = getClass().getResource("/cloudgamespic.png").toExternalForm();
        BackgroundImage backgroundImage = new BackgroundImage(
                new javafx.scene.image.Image(imagePath),
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(
                        BackgroundSize.AUTO,
                        BackgroundSize.AUTO,
                        true,
                        true,
                        true,
                        false));

        // Set the background image to the Pane
        root.setBackground(new Background(backgroundImage));

        // Create the Scene
        Scene scene = new Scene(root, 1280, 720);

        // Set the stage
        stage.setTitle("Background Image Demo");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
