package com.example.demo;

import java.sql.DriverManager;
import java.util.Enumeration;
import java.sql.Driver;

public class DriverDebug {
    public static void main(String[] args) {
        Enumeration<Driver> drivers = DriverManager.getDrivers();
        if (!drivers.hasMoreElements()) {
            System.out.println("No JDBC drivers found!");
        } else {
            while (drivers.hasMoreElements()) {
                Driver driver = drivers.nextElement();
                System.out.println("Loaded driver: " + driver.getClass().getName());
            }
        }
    }
}
