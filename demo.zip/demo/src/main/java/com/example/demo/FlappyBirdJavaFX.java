package com.example.demo;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class FlappyBirdJavaFX extends Application {

    public static void main(String[] args) {
        // Launch the JavaFX application
        launch(args);
    }

    @Override
    public void start(Stage flappyStage) {
        // Set up JavaFX stage
        flappyStage.setTitle("Flappy Bird - JavaFX");
        int boardWidth = 360;
        int boardHeight = 640;

        // Create a simple placeholder for the game
        StackPane root = new StackPane();
        Rectangle placeholder = new Rectangle(boardWidth, boardHeight, Color.LIGHTBLUE);
        root.getChildren().add(placeholder);

        Scene scene = new Scene(root, boardWidth, boardHeight);
        flappyStage.setScene(scene);
        flappyStage.setResizable(false);
        flappyStage.show();
    }
}