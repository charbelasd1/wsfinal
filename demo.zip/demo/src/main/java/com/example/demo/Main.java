package com.example.demo;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

    public void start(Stage primaryStage) {
        MazeGame game = new MazeGame();
        game.start(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}