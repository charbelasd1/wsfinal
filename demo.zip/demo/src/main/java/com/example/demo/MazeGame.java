package com.example.demo;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MazeGame extends Application {
    private int CELL_SIZE = 20; // Initial size of each cell
    private final int ROWS = 25; // Number of rows
    private final int COLS = 30; // Number of columns
    private Player player;
    private MazeGenerator maze;
    private Canvas canvas;
    private Image playerIcon;
    private Image finishLineIcon;
    private int timeLeft = 60; // Timer starts at 60 seconds
    private Timeline timer;
    private Label timerLabel;
    private Label resultLabel; // Label to display "You Lose" or "You Win" messages
    private Label highScoreLabel; // Label to display the high score
    private int highScore = Integer.MAX_VALUE; // Initialize high score with a large value
    private boolean gameOver = false; // To prevent input after game ends
    private boolean gameStarted = false; // To prevent interactions until game starts
    private ComboBox<String> characterSelection; // Dropdown for character selection

    private final String[] characterImages = {
            "supermario.png",
            "cat.png",
            "jerry pic.png",
            "tom pic.png",
            "pink panther pic.png"
    };

    @Override
    public void start(Stage primaryStage) {
        // Initialize canvas based on ROWS, COLS, and CELL_SIZE
        canvas = new Canvas(COLS * CELL_SIZE, ROWS * CELL_SIZE);

        // Initialize player and maze
        player = new Player(0, 0);
        maze = new MazeGenerator(ROWS, COLS);
        maze.getMaze()[ROWS - 1][COLS - 1] = 1; // Ensure finish point is reachable

        // Load player icon and finish line icon
        try {
            playerIcon = new Image(characterImages[0]); // Default character
            finishLineIcon = new Image("file:///C:/Users/Marc%20Rabbat/Desktop/finishline.png");
        } catch (Exception e) {
            System.out.println("Error loading images: " + e.getMessage());
            System.exit(1); // Exit if image loading fails
        }

        drawMaze();

        // Create timer label
        timerLabel = new Label("Time Left: " + timeLeft + "s");
        timerLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Create high score label
        highScoreLabel = new Label("High Score: N/A");
        highScoreLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Create result label for "You Lose" or "You Win" messages
        resultLabel = new Label();
        resultLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // Create Start button
        Button startButton = new Button("Start");
        startButton.setOnAction(e -> startGame(startButton));

        // Create restart and exit buttons
        Button retryButton = new Button("Restart");
        retryButton.setOnAction(e -> restartGame(startButton));
        Button exitButton = new Button("Exit");
        exitButton.setOnAction(e -> System.exit(0));

        // Create character selection dropdown
        characterSelection = new ComboBox<>();
        characterSelection.getItems().addAll("Super Mario", "Cat", "Jerry", "Tom", "Pink Panther");
        characterSelection.setValue("Super Mario");
        characterSelection.setOnAction(e -> updateCharacter());

        // Organize UI components
        HBox buttonBar = new HBox(10, startButton, retryButton, exitButton, characterSelection);
        buttonBar.setStyle("-fx-alignment: center; -fx-padding: 10px;");

        HBox topBar = new HBox(10, timerLabel, highScoreLabel, resultLabel);
        topBar.setStyle("-fx-alignment: center; -fx-padding: 10px; -fx-spacing: 20px;");

        VBox centerBox = new VBox(10, canvas);
        centerBox.setStyle("-fx-alignment: center; -fx-padding: 10px;");

        // Layout: BorderPane
        BorderPane root = new BorderPane();
        root.setTop(topBar);
        root.setCenter(centerBox);
        root.setBottom(buttonBar);

        // Create the scene
        Scene scene = new Scene(root);
        scene.setOnKeyPressed(this::handleMovement);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Maze Escape Game");
        primaryStage.setResizable(true); // Enable resizing
        primaryStage.setWidth(COLS * CELL_SIZE + 50);
        primaryStage.setHeight(ROWS * CELL_SIZE + 150);

        // Handle resizing
        primaryStage.widthProperty().addListener((obs, oldVal, newVal) -> handleResize(primaryStage));
        primaryStage.heightProperty().addListener((obs, oldVal, newVal) -> handleResize(primaryStage));

        primaryStage.show();
    }

    private void handleResize(Stage stage) {
        double newWidth = stage.getWidth() - 50;
        double newHeight = stage.getHeight() - 150;
        CELL_SIZE = Math.max(10, Math.min(40, (int) Math.min(newWidth / COLS, newHeight / ROWS)));
        canvas.setWidth(COLS * CELL_SIZE);
        canvas.setHeight(ROWS * CELL_SIZE);
        drawMaze();
    }

    private void startGame(Button startButton) {
        gameStarted = true;
        gameOver = false; // Reset game over state
        startButton.setDisable(true); // Disable the start button after starting
        resultLabel.setText(""); // Clear any previous result messages
        startTimer(); // Start the timer
    }

    private void updateCharacter() {
        int selectedIndex = characterSelection.getSelectionModel().getSelectedIndex();
        try {
            playerIcon = new Image(characterImages[selectedIndex]);
            drawMaze();
        } catch (Exception e) {
            System.out.println("Error loading character image: " + e.getMessage());
        }
    }

    private void handleMovement(KeyEvent event) {
        if (!gameStarted || gameOver) return; // Prevent movement if the game hasn't started or is over

        int[][] grid = maze.getMaze();
        int row = player.getRow();
        int col = player.getCol();

        if ((event.getCode() == KeyCode.UP || event.getCode() == KeyCode.W) && row > 0 && grid[row - 1][col] == 1) {
            player.moveUp();
        }
        if ((event.getCode() == KeyCode.DOWN || event.getCode() == KeyCode.S) && row < ROWS - 1 && grid[row + 1][col] == 1) {
            player.moveDown();
        }
        if ((event.getCode() == KeyCode.LEFT || event.getCode() == KeyCode.A) && col > 0 && grid[row][col - 1] == 1) {
            player.moveLeft();
        }
        if ((event.getCode() == KeyCode.RIGHT || event.getCode() == KeyCode.D) && col < COLS - 1 && grid[row][col + 1] == 1) {
            player.moveRight();
        }

        drawMaze();

        if (player.getRow() == ROWS - 1 && player.getCol() == COLS - 1) {
            stopTimer();
            showWinMessage();
        }
    }

    private void drawMaze() {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        int[][] grid = maze.getMaze();
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                gc.setFill(grid[row][col] == 0 ? Color.BLACK : Color.WHITE);
                gc.fillRect(col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE);
            }
        }

        // Draw the finish line as an image
        gc.drawImage(finishLineIcon, (COLS - 1) * CELL_SIZE, (ROWS - 1) * CELL_SIZE, CELL_SIZE, CELL_SIZE);

        // Draw the player icon
        gc.drawImage(playerIcon, player.getCol() * CELL_SIZE, player.getRow() * CELL_SIZE, CELL_SIZE, CELL_SIZE);
    }

    private void startTimer() {
        timer = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            timeLeft--;
            timerLabel.setText("Time Left: " + timeLeft + "s");

            if (timeLeft <= 0) {
                stopTimer();
                showLoseMessage();
            }
        }));
        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();
    }

    private void stopTimer() {
        if (timer != null) timer.stop();
    }

    private void showWinMessage() {
        resultLabel.setText("You Win!");
        resultLabel.setTextFill(Color.GREEN);
        gameOver = true;

        if (60 - timeLeft < highScore) {
            highScore = 60 - timeLeft;
            highScoreLabel.setText("High Score: " + highScore + "s");
        }
    }

    private void showLoseMessage() {
        resultLabel.setText("You Lose! Time's Up!");
        resultLabel.setTextFill(Color.RED);
        gameOver = true;
    }

    private void restartGame(Button startButton) {
        gameOver = false;
        gameStarted = false; // Reset the start condition
        timeLeft = 60;
        timerLabel.setText("Time Left: " + timeLeft + "s");
        resultLabel.setText("");
        player = new Player(0, 0);
        maze = new MazeGenerator(ROWS, COLS);
        maze.getMaze()[ROWS - 1][COLS - 1] = 1;
        startButton.setDisable(false); // Re-enable the Start button
        drawMaze();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
