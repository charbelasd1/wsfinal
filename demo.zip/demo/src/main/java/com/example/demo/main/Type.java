package com.example.demo.main;


public enum Type {

    PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING
}
